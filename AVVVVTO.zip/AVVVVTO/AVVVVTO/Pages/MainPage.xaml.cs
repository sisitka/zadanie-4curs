﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AVVVVTO.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (App.CurrentUser != null)
            {
                FullNameTextBlock.Text = App.CurrentUser.FullName;
                RoleTextBlock.Text = App.CurrentUser.Roles?.RoleName ?? "Без роли ";
                int roleId = App.CurrentUser.RoleId;
                if (roleId == 1)
                {

                }
                else if (roleId == 2) 
                    {
                        ClientsBtn.Visibility = Visibility.Collapsed;
                        CarsBtn.Visibility = Visibility.Collapsed;
                        UsersBtn.Visibility = Visibility.Collapsed;
                    }
                    else if (roleId == 3)
                {
                    ClientsBtn.Visibility = Visibility.Collapsed;
                    ServicesBtn.Visibility = Visibility.Collapsed;
                    UsersBtn.Visibility= Visibility.Collapsed;
                }
            }


        }
        private void ClientsBtn_Click(object sender, RoutedEventArgs e)
        {
            SectionFrame.Navigate(new ClientsPage());
        }
            
        private void CarsBtn_Click(object sender, RoutedEventArgs e)
        {
            SectionFrame.Navigate(new CarsPage());
        }
        
        private void ServicesBtn_Click(object sender, RoutedEventArgs e)
        {
            SectionFrame.Navigate(new ServicesPage());
        }
            
        private void OrdersBtn_Click(object sender, RoutedEventArgs e)
        {
            SectionFrame.Navigate(new OrdersPage());
        }
            
        private void UsersBtn_Click(object sender, RoutedEventArgs e)
        {
            SectionFrame.Navigate(new UsersPage());
        }
            



        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentUser = null;
            NavigationService.Navigate(new LoginPage());
        }
    }
}
