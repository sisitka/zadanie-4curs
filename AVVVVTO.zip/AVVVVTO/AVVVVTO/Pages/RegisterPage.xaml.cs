﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AVVVVTO.Pages
{
    /// <summary>
    /// Логика взаимодействия для RegisterPage.xaml
    /// </summary>
    public partial class RegisterPage : Page
    {
        public RegisterPage()
        {
            InitializeComponent();
        }
        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string fullName = FullNameTextBox.Text;
            string login = LoginTextBox.Text;
            string password = PasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;
            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword) )
            {
                MessageBox.Show("Заполни все поля");
                return;
            }
            if (password!= confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают");
            }
            var userExists = App.DB.Users.Any(u=> u.Login == login);
            if (userExists) 
            {
                MessageBox.Show("Пользователь с таким логином уже существует!");
                return;
            }
            try
            {
                var newUser = new Users
                {
                    FullName = fullName,
                    Login = login,
                    Password = password,
                    RoleId = 3
                };
                App.DB.Users.Add(newUser);
                App.DB.SaveChanges();
                MessageBox.Show("Успешно");
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка" + ex.Message);
            }

        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
