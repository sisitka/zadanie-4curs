﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarServise.Pages
{
    /// <summary>
    /// Логика взаимодействия для SihnUpPage.xaml
    /// </summary>
    public partial class SihnUpPage : Page
    {
        
        public SihnUpPage()
        {
            InitializeComponent();
            CBRole.ItemsSource = App.DB.Roles.ToList();
        }

        private void BTReg_Click(object sender, RoutedEventArgs e)
        {
            string login = TBlogin.Text;
            string password = TBpassword.Text;
            string passwordpov = TBPasswordpovtor.Text;

            var user = App.DB.Users.FirstOrDefault(x => x.Login == login);
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(passwordpov) || string.IsNullOrWhiteSpace(TBName.ToString()))
                {
                TBPasswordpovtor.Text = "Заполни всё!!";
            }
        
            else
            {
                if(user!=null)
                {
                    if(password==passwordpov)
                    {
                        user.FullName = TBName.Text;
                        user.Login = TBlogin.Text;
                        user.Password = TBpassword.Text;
                        user.RoleId = 1;
                        App.DB.Users.Add(user);
                        App.DB.SaveChanges();
                        MessageBox.Show("Всё создано");
                        NavigationService.GoBack();

                    }
                    else
                    {
                        TBPasswordpovtor.Text = "Пароли оличаются";
                    }
                }
                else
                {
                    TBlogin.Visibility = Visibility.Visible;
                }
            }
        }
    }
}
