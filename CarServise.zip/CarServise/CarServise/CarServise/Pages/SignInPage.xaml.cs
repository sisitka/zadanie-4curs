﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarServise.Pages
{
    /// <summary>
    /// Логика взаимодействия для SignIn.xaml
    /// </summary>
    public partial class SignInPage : Page
    {
        public SignInPage()
        {
            InitializeComponent();
            CBRole.ItemsSource = App.DB.Roles.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string login = TBlogin.Text;
            string password = PBpassword.Password;
            var user = App.DB.Users.FirstOrDefault(x => x.Login == login && x.Password==password);

            if(user!= null)

            {
                MessageBox.Show("маладец");
                NavigationService.Navigate(new MenuPage());
            }
            else
            {
                MessageBox.Show("не маладец");
            }
        }



        private void SignUp_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new SihnUpPage());
        }
    }
}
