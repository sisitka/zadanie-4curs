﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace avto.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string login = TBLogin.Text;
            string password = PBPassword.Password;
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("заполни все поля");
                return;
            }
            try
            {
                var user = App.DB.Users.Include("Roles").FirstOrDefault(x => x.Login == login && x.Password == password);
                if (user != null)
                {
                    App.CurrentUser = user;
                    MessageBox.Show("добро пожаловать");
                    NavigationService.Navigate(new MainPage());
                }
                else
                {
                    MessageBox.Show("не верно");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ошиька");
            }
        }
        
        
        
        private void reg_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RegistrPage());
        }
    }
}
