﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace avto.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void BTCancel_Click(object sender, RoutedEventArgs e)
        {
            if (App.CurrentUser is Users user)
            {
                TextBName.Text = user.FullName;
                TextBRole.Text =  $"Роль: { user.Roles.RoleName}";
                if (user.RoleId == 2)
                {
                    BTClients.Visibility = Visibility.Collapsed;
                    BTServices.Visibility = Visibility.Collapsed;
                    BTCars.Visibility = Visibility.Collapsed;
                }
                else if (user.RoleId == 3) 
                        {
                    BTClients.Visibility = Visibility.Collapsed;
                    BTServices.Visibility = Visibility.Collapsed;
                }
            }
            else
            {
                NavigationService.Navigate(new LoginPage());
            }
        }

        private void BTCancel_Click1(object sender, RoutedEventArgs e)
        {
            App.CurrentUser = null;
            NavigationService.Navigate(new LoginPage());
        }
    }
}
